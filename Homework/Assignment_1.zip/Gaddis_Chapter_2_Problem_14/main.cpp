
/* 
 * File:   main.cpp
 * Author: Kuldeep Singh
 * Created on September 17, 2017, 3:10 PM
 * Purpose: Write Personal Information with only one cout
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    cout<<"Kuldeep Singh "<<endl<<"123 Fake Address, Riverside, CA, 12345"<<endl<<"555-555-5555"<<endl<<"Computer Science"<<endl;

    return 0;
}

