/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Kuldeep Singh
 * Created on September 17, 2017, 1:51 PM
 * Purpose: Sum of Two Integers
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int a,b,total; 
    a=50;
    b=100;
    total=a+b;
    cout<<"The Sum of 50 and 100 is "<<total;          

    return 0;
}

