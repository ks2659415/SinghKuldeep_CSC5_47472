
/* 
 * File:   main.cpp
 * Author: Kuldeep Singh
 * Created on September 17, 2017, 3:40 PM
 * Purpose: Make a Triangle
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;

    return 0;
}

